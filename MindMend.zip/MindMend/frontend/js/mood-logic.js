document.addEventListener('DOMContentLoaded', () => {
    // 1. Get references to the mood buttons
    const greatBtn = document.querySelector('.mood-btn.great');
    const goodBtn = document.querySelector('.mood-btn.good');
    const okayBtn = document.querySelector('.mood-btn.okay');
    const badBtn = document.querySelector('.mood-btn.bad');
    const criticalBtn = document.querySelector('.mood-btn.critical');
    
    // 2. Get references to the level display elements
    const highLevel = document.querySelector('.level-card.high');
    const mediumLevel = document.querySelector('.level-card.medium');
    const lowLevel = document.querySelector('.level-card.low');

    // Function to update the bar and percentage text for a specific level card
    function updateLevelDisplay(targetElement, percentage) {
        if (!targetElement) return;

        const fillBar = targetElement.querySelector('.level-fill');
        const percentageText = targetElement.querySelector('.percentage-text');
        
        // 1. Update the percentage text
        percentageText.textContent = `${percentage}%`;

        // 2. Update the fill bar width (triggers the CSS transition)
        setTimeout(() => {
            fillBar.style.width = `${percentage}%`;
        }, 50); 
    }

    // Function to reset all level displays (hide bars and reset text)
    function resetDisplays() {
        const allLevels = [highLevel, mediumLevel, lowLevel];
        allLevels.forEach(card => {
            if (card) {
                card.querySelector('.level-fill').style.width = '0%';
                card.querySelector('.percentage-text').textContent = '--%'; 
            }
        });
    }

    // Reset initial state (hides bars until a mood is clicked)
    resetDisplays();
    
    // 3. Add Event Listeners to Mood Buttons
    
    // Logic: GREAT (High Positive Emotion)
    greatBtn.addEventListener('click', () => {
        resetDisplays();
        updateLevelDisplay(highLevel, 95); // High level of positive feeling
        updateLevelDisplay(mediumLevel, 20); 
        updateLevelDisplay(lowLevel, 5); 
    });

    // Logic: GOOD (Moderate Positive Emotion)
    goodBtn.addEventListener('click', () => {
        resetDisplays();
        updateLevelDisplay(highLevel, 45); 
        updateLevelDisplay(mediumLevel, 70); // Medium level is strongest
        updateLevelDisplay(lowLevel, 15);
    });

    // Logic: OKAY (Neutral/Low Emotion)
    okayBtn.addEventListener('click', () => {
        resetDisplays();
        updateLevelDisplay(highLevel, 10);
        updateLevelDisplay(mediumLevel, 35); 
        updateLevelDisplay(lowLevel, 60); // Low level of energy/intensity
    });

    // Logic: BAD (Moderate Negative Emotion)
    badBtn.addEventListener('click', () => {
        resetDisplays();
        // Assuming High represents Intensity of Negative emotion (e.g., sadness, anger)
        updateLevelDisplay(highLevel, 80); 
        updateLevelDisplay(mediumLevel, 50); 
        updateLevelDisplay(lowLevel, 20); 
    });

    // Logic: CRITICAL (High Negative Emotion)
    criticalBtn.addEventListener('click', () => {
        resetDisplays();
        // Assuming Critical results in max emotional intensity
        updateLevelDisplay(highLevel, 98); 
        updateLevelDisplay(mediumLevel, 65); 
        updateLevelDisplay(lowLevel, 5); 
    });
});