import express from "express";
import cors from "cors";
import Groq from "groq-sdk";
import dotenv from "dotenv";
dotenv.config({ path: "./.env" });


const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

const app = express();
app.use(cors());
app.use(express.json());

app.post("/api/affirmation", async (req, res) => {
  try {
    const { text } = req.body;

    const prompt = `You feel "${text}". Generate 3 short, positive, motivating affirmations.`;

    const completion = await groq.chat.completions.create({
    model: "llama-3.1-8b-instant",
    messages: [
        {
            role: "user",
            content: "Generate a short positive affirmation about confidence."
        }
    ]
});


    const reply = completion.choices[0].message.content;
    res.json({ affirmation: reply });

  } catch (err) {
    console.error("Error:", err);
    res.status(500).json({ error: "Error generating affirmation" });
  }
});

app.listen(5000, () => console.log("Server running on port 5000"));
