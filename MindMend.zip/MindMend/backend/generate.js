import express from "express";
import fetch from "node-fetch";
import dotenv from "dotenv";

dotenv.config();
const router = express.Router();

router.post("/affirmation", async (req, res) => {
  const { text } = req.body;

  try {
    const response = await fetch(
      "https://api-inference.huggingface.co/models/gpt2",
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${process.env.HF_TOKEN}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          inputs: `Write a positive, short affirmation for someone feeling: ${text}`,
        }),
      }
    );

    const data = await response.json();
    const output = data?.[0]?.generated_text || "You are strong.";

    res.json({ affirmation: output });
  } catch (err) {
    res.status(500).json({ error: "Failed to generate" });
  }
});

export default router;
